function x = range(y)

x = max(y)-min(y);

